﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day10_Database_Grid
{
    public partial class Form1 : Form

    {

        public Form1()

        {

            InitializeComponent();

        }



        private void button1_Click(object sender, EventArgs e)

        {

            //creating a Connection Object 

            string connectionString = "Data Source=;Initial Catalog=;Persist Security Info=True;User ID=;Password=";

            SqlConnection myConnection = new SqlConnection();

            myConnection.ConnectionString = connectionString;



            myConnection.Open();



            //creating a SQL string and Data adapter object 

            string queryString = "select * from student1";
            //string queryString1 = "select * from ranighosh_student1";


            SqlDataAdapter mydataAdapter = new SqlDataAdapter(queryString, myConnection.ConnectionString);
           // SqlDataAdapter mydataAdapter1 = new SqlDataAdapter(queryString1, myConnection.ConnectionString);




            //myConnection.Close(); 



            //creating dataset/datatable andf filling it 

            DataSet dataSet = new DataSet("student1");
           // DataSet dataSet1 = new DataSet("ranighosh_student1");


            //DataTable dt = new DataTable("student1"); 

            //mydataAdapter.Fill(dt); 

            mydataAdapter.Fill(dataSet);
           // mydataAdapter1.Fill(dataSet);




            //Binding the DataGrid control to DataSet 

            dataGridView1.DataSource = dataSet.Tables[0].DefaultView; //Showing the First table of the Dataset 
            //dataGridView1.DataSource = dataSet.Tables[1].DefaultView; //Showing the Second table of the Dataset 



            //myConnection.Dispose(); 



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
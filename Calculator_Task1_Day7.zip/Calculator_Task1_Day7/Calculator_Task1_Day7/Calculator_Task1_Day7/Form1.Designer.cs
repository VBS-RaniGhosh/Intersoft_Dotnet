﻿
namespace Calculator_Task1_Day7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.b7 = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.TextBox();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.bsub = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.bclr = new System.Windows.Forms.Button();
            this.bmul = new System.Windows.Forms.Button();
            this.beql = new System.Windows.Forms.Button();
            this.badd = new System.Windows.Forms.Button();
            this.bdot = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // b7
            // 
            this.b7.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(32, 76);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(30, 31);
            this.b7.TabIndex = 0;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b_click);
            // 
            // textBox
            // 
            this.textBox.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox.ForeColor = System.Drawing.Color.DarkSeaGreen;
            this.textBox.Location = new System.Drawing.Point(14, 30);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(177, 29);
            this.textBox.TabIndex = 1;
            this.textBox.Text = "0";
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // b8
            // 
            this.b8.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(68, 76);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(30, 31);
            this.b8.TabIndex = 2;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b_click);
            // 
            // b9
            // 
            this.b9.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(104, 76);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(30, 31);
            this.b9.TabIndex = 3;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b_click);
            // 
            // bdiv
            // 
            this.bdiv.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdiv.Location = new System.Drawing.Point(143, 76);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(30, 31);
            this.bdiv.TabIndex = 5;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = true;
            this.bdiv.Click += new System.EventHandler(this.op_click);
            // 
            // b6
            // 
            this.b6.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(104, 113);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(30, 31);
            this.b6.TabIndex = 6;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b_click);
            // 
            // b5
            // 
            this.b5.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(68, 113);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(30, 31);
            this.b5.TabIndex = 7;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b_click);
            // 
            // b4
            // 
            this.b4.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(32, 113);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(30, 31);
            this.b4.TabIndex = 8;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b_click);
            // 
            // bsub
            // 
            this.bsub.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bsub.Location = new System.Drawing.Point(143, 150);
            this.bsub.Name = "bsub";
            this.bsub.Size = new System.Drawing.Size(30, 31);
            this.bsub.TabIndex = 9;
            this.bsub.Text = "-";
            this.bsub.UseVisualStyleBackColor = true;
            this.bsub.Click += new System.EventHandler(this.op_click);
            // 
            // b3
            // 
            this.b3.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(104, 150);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(30, 31);
            this.b3.TabIndex = 10;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b_click);
            // 
            // b2
            // 
            this.b2.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(68, 150);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(30, 31);
            this.b2.TabIndex = 11;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b_click);
            // 
            // b1
            // 
            this.b1.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(32, 150);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(30, 31);
            this.b1.TabIndex = 12;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b_click);
            // 
            // bclr
            // 
            this.bclr.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bclr.Location = new System.Drawing.Point(32, 224);
            this.bclr.Name = "bclr";
            this.bclr.Size = new System.Drawing.Size(75, 31);
            this.bclr.TabIndex = 13;
            this.bclr.Text = "CE";
            this.bclr.UseVisualStyleBackColor = true;
            this.bclr.Click += new System.EventHandler(this.CE_click);
            // 
            // bmul
            // 
            this.bmul.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmul.Location = new System.Drawing.Point(143, 113);
            this.bmul.Name = "bmul";
            this.bmul.Size = new System.Drawing.Size(30, 31);
            this.bmul.TabIndex = 14;
            this.bmul.Text = "*";
            this.bmul.UseVisualStyleBackColor = true;
            this.bmul.Click += new System.EventHandler(this.op_click);
            // 
            // beql
            // 
            this.beql.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beql.Location = new System.Drawing.Point(113, 224);
            this.beql.Name = "beql";
            this.beql.Size = new System.Drawing.Size(60, 31);
            this.beql.TabIndex = 16;
            this.beql.Text = "=";
            this.beql.UseVisualStyleBackColor = true;
            this.beql.Click += new System.EventHandler(this.b_eql);
            // 
            // badd
            // 
            this.badd.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.badd.Location = new System.Drawing.Point(143, 187);
            this.badd.Name = "badd";
            this.badd.Size = new System.Drawing.Size(30, 31);
            this.badd.TabIndex = 17;
            this.badd.Text = "+";
            this.badd.UseVisualStyleBackColor = true;
            this.badd.Click += new System.EventHandler(this.op_click);
            // 
            // bdot
            // 
            this.bdot.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdot.Location = new System.Drawing.Point(32, 187);
            this.bdot.Name = "bdot";
            this.bdot.Size = new System.Drawing.Size(30, 31);
            this.bdot.TabIndex = 18;
            this.bdot.Text = ".";
            this.bdot.UseVisualStyleBackColor = true;
            this.bdot.Click += new System.EventHandler(this.b_click);
            // 
            // b0
            // 
            this.b0.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.Location = new System.Drawing.Point(68, 187);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(66, 31);
            this.b0.TabIndex = 19;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.b_click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(122, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 20;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(210, 270);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bdot);
            this.Controls.Add(this.badd);
            this.Controls.Add(this.beql);
            this.Controls.Add(this.bmul);
            this.Controls.Add(this.bclr);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.bsub);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.b7);
            this.ForeColor = System.Drawing.Color.Crimson;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Rani_Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button bdiv;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button bsub;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button bclr;
        private System.Windows.Forms.Button bmul;
        private System.Windows.Forms.Button beql;
        private System.Windows.Forms.Button badd;
        private System.Windows.Forms.Button bdot;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Label label1;
    }
}


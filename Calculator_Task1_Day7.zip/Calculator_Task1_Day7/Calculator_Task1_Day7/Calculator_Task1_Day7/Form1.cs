﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_Task1_Day7
{
    public partial class Form1 : Form
    {
        Double output = 0;
        String operation = "";
        bool is_Opt_Performed = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void b_click(object sender, EventArgs e)
        {
            if((textBox.Text == "0") || (is_Opt_Performed))
                textBox.Clear();
           
            Button b = (Button) sender;
            is_Opt_Performed = false;
            if (b.Text == ".")
            {
                if (!textBox.Text.Contains("."))
                    textBox.Text = textBox.Text + b.Text;

            }
            else
                textBox.Text = textBox.Text + b.Text;
           


        }

        private void op_click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            operation = b.Text;
            output = Double.Parse(textBox.Text);
            label1.Text = output + " " + operation;
            is_Opt_Performed = true;
            

        }

        private void b_eql(object sender, EventArgs e)
        {
            switch(operation)
            {
                case "+":
                    textBox.Text = (output + Double.Parse(textBox.Text)).ToString();
                    break;
                case "-":
                    textBox.Text = (output - Double.Parse(textBox.Text)).ToString();
                break;
           
                case "*":
                    textBox.Text = (output * Double.Parse(textBox.Text)).ToString();
                break;

              case "/":
                    textBox.Text = (output / Double.Parse(textBox.Text)).ToString();
                break;

                default:
                    break;

            }
        }

        private void CE_click(object sender, EventArgs e)
        {
            textBox.Text = "0";
            label1.Text = "0";

        }

        private void c_click(object sender, EventArgs e)
        {
            textBox.Text = "0";
            output = 0;
            label1.Text = output.ToString();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
    
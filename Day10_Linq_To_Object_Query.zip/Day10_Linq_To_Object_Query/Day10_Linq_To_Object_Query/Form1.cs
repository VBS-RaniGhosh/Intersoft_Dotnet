﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Day10_Linq_To_Object_Query
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Defining a String Array

            string[] names = {" Wings of FIRE",

                                "Rich Dad Poor Dad ",

                                "Deepwork",

                                "Think Rich Grow MORE",

                                "Every One You hate is going to DIE"};

            //LINQ Query 



            IEnumerable<string> AlltimeFavBooks = from name in names

                                                  where name.Length > 5

                                                  select name;

            //For each to display Objects 

            foreach (var name in AlltimeFavBooks)

            {

                richTextBox1.AppendText(name + "\n");

            }
        }
    }
}

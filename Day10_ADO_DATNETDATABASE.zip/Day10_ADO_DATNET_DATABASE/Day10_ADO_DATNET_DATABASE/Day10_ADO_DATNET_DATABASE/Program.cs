﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day10_ADO_DATNET_DATABASE
{
    internal class Program

    {

        static void Main(string[] args)

        {

            //Step 1: Creating a Connection 

            //Step 2: Creating Querystring 

            //Step 3: Opening Connection 

            //Step 4: Creating SQL Command 

            //Step 5: Reading Data using SQLDATAREADER class 

            string ConnString = "Data Source=;Initial Catalog=;Persist Security Info=True;User ID=;Password=";

            SqlConnection conn = new SqlConnection(ConnString);



            string querystring = " Select * from ranighosh_employee ";

            conn.Open();

            SqlCommand cmd = new SqlCommand(querystring, conn);//Running Querystring on the specified connection string 

            SqlDataReader reader = cmd.ExecuteReader();

            //Console.WriteLine(reader); 



            Console.WriteLine(reader.FieldCount);

            while (reader.Read())

            {

                for (int i = 0; i < reader.FieldCount; i++)

                {

                    Console.Write(reader[i].ToString() + " ");

                }

                Console.WriteLine("--");

                //Console.WriteLine(reader[0].ToString() + " Name is :" + reader[1].ToString() + 

                //    " And Subject is :" + reader[2].ToString() /*+ " " + reader[3].ToString()*/); 

            }





        }

    }

} 


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, curr = 0;
            int[] arr = new int[20];
            int i, j, k;

            Console.WriteLine("Enter the number of elements to be stored in the array :");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input {0} elements in the array :\n", n);
            for (i = 0; i < n; i++)
            {
                Console.WriteLine("element : {0} : ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("\nThe unique elements found in the array are :");
            for (i = 0; i < n; i++)
            {
                curr = 0;
                for (j = 0; j < i - 1; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        curr++;
                    }
                }
                for (k = i + 1; k < n; k++)
                {
                    if (arr[i] == arr[k])
                    {
                        curr++;
                    }
                    if (arr[i] == arr[i + 1])
                    {
                        i++;
                    }
                }
                if (curr == 0)
                {
                    Console.WriteLine("{0} ", arr[i]);
                }
            }

        }
    }
}

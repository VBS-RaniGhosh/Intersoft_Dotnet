﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ques__4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 3;
            int[,] arr = new int[n, n];
            Console.WriteLine("Enter your Matrix element:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                   
                    arr[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(arr[i, j] + " ");
                }
                Console.WriteLine("");
            }
            Console.ReadKey();
        }

    }
}

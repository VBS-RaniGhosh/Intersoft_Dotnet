﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignment_3
{
    public class MyThread
    {
        public void Tdisplay()
        {
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("My thread");
            }
        }
    }

    class Program
    {
        [Obsolete]
        static void Main(string[] args)
        {
            MyThread obj = new MyThread();
            Thread T1 = new Thread(new ThreadStart(obj.Tdisplay));
            Console.WriteLine("ThreadState:{0}", T1.ThreadState);

            T1.Start();
            Console.WriteLine("ThreadState: {0}", T1.ThreadState);

            T1.Suspend();
            Console.WriteLine("ThreadState: {0}", T1.ThreadState);

            T1.Resume();
            Console.WriteLine("ThreadState: {0}", T1.ThreadState);



        }
    }
}

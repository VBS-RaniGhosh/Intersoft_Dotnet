﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



namespace Assignment2_Day9

//Checking current state of a thread 

{
    class Program
    {
        public static void check()
        {
            Thread.Sleep(2000);
        }


        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(check));

            Console.WriteLine("ThreadState of t1 thread is : {0}", t1.ThreadState);
            t1.Start();
            Console.WriteLine("ThreadState of t1 thread is : {0}", t1.ThreadState);
            Thread.Sleep(100);

            Thread t2 = new Thread(new ThreadStart(check));
            Console.WriteLine("ThreadState of t2 thread is : {0}", t2.ThreadState);
            t2.Start();
            Console.WriteLine("ThreadState of t2 thread is : {0}", t2.ThreadState);


        }
    }
}

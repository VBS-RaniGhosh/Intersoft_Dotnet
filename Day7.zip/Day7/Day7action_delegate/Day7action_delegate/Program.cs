﻿using System;

namespace Day7action_delegate
{
    internal class Program
    {
        public static void Display( string message)
        {
            Console.WriteLine("Here we are instantiating Action<T> delegate");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Action delegate working");

            Action<string> messagetarget;

            if (Environment.GetCommandLineArgs().Length > 1)
            {
                messagetarget = Display;

            }
            else
            {
                messagetarget = Console.WriteLine;
                messagetarget("Hello World - This is the else part of the condition");
            }

        }
    }
}

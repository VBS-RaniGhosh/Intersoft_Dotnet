﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Multiple_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Calulator c1 = new Calulator();
            Console.WriteLine(c1.add(6, 9));
            Console.WriteLine(c1.add(6.78f, 9.99f));
            //Console.WriteLine(c1.subtract(3, 5));

        }
    }
}
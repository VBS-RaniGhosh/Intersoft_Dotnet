﻿
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day9Serialization_Deserialization
{
    class Program
    {
        static void Main(string[] args)
        { 
            Tutorial ob = new Tutorial();
            ob.ID = 1;
            ob.Name = "ASP.NET MVC";

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("C:\\Users\\Rani Ghosh\\source\\repos\\" +
                "Day9Serialization_Deserialization\\" +
                "Day9Serialization_Deserialization\\demoText.txt", FileMode.Create, FileAccess.Write);


            //Serializing the object
            formatter.Serialize(stream, ob);
            Console.WriteLine(" Objects has been serislized...!!!");
            stream.Close();
            
            Stream stream1 = new FileStream("C:\\Users\\Rani Ghosh\\source\\repos\\Day9Serialization_Deserialization\\" +
                "Day9Serialization_Deserialization\\demoText.txt",FileMode.Open, FileAccess.Read);

            Tutorial ObjNew = (Tutorial) formatter.Deserialize(stream1);
            Console.WriteLine("Data After Deserialization is like");
            Console.WriteLine(ObjNew.ID);
            Console.WriteLine(ObjNew.Name);


        }
    }
}

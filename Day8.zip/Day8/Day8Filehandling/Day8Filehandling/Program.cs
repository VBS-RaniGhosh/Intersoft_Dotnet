﻿using System;

namespace Day8FileHandling
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Working with Streams");
            FileWrite wr = new FileWrite();
            wr.WriteData();
            Console.WriteLine("Reading Data From the file ");
            wr.ReadData();
        }
    }
}
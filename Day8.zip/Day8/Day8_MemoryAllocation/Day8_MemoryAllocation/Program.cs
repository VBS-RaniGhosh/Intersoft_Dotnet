﻿using System;

namespace Day8_MemoryAllocation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Destructors in C#");

            Complex C = new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
           // Console.WriteLine("End of code..");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8Destructor
{
    class Program
    { 
        public static void Free()
        {
            Complex C3 = new Complex();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Destructors in C#");

            Complex C = new Complex();
            C.SetValue(4, 7);
            C.DisplayValue();
            C.Dispose();
            // Console.WriteLine("End of code..");
        }
    }
}

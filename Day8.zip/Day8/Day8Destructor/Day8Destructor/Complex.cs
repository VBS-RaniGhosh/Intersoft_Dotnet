﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8Destructor
{
    //Idisposable- this interface contains Dispose() for releasing unmanaged resources files, connection string, Streams etc.
    class Complex :IDisposable 
    {
        int real, imaginary;

        public Complex()
        {

            real = 0;
            imaginary = 0;
        }
        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }
        public void DisplayValue()
        {
            Console.WriteLine("real =" + real);
            Console.WriteLine("imaginary =" + imaginary);

        }
        public void Dispose()
        {
            Dispose(true);
            Console.WriteLine("Dispose() is called to dispose unmanaged resources..");
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
                Console.WriteLine("Cleaning up all managed resources - alomg with child object implementing imposible ");
        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called");
            // C# compiler will convert this destructor into finalize
            Dispose(false);
        }
    }
}

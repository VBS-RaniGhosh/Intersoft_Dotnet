﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8Shallow_Deep_Copies
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Deep Copying taking place As memory ref is same");
            shallow obj = new shallow();
            shallow objClone = obj;
            obj.I = 101; //Setting obj value after cloning
            Console.WriteLine("objvalue: {0} /t Clone Value :(1)", obj.I, objClone.I);

            Console.WriteLine("--------------------After Implementing Shallow Copying Using Clone()------------------------");
            shallow obj2 = (shallow)obj.Clone();
            obj2.I = 201;
            Console.WriteLine("After using MemberWiseClone(){0}", obj2.I);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq; //provides classes and interfaces that support LINQ queries
using System.Text;
using System.Threading.Tasks;

namespace Day10_Linq_Types
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[] { 1, 2, 5, 9, 12 }; //ARRAY OF INTEGERS
            var result = from a 
                         in num where a < 4 
                         orderby a select a;
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopWatch_Task2_Day7
{
    public partial class Form1 : Form
    {
        int seconds;
        int mintues;
        int hours;
        int progress;

        public Form1()
        {
            InitializeComponent();
            hours = mintues = seconds = 0;
        }

        private void lsec_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lmin_Click(object sender, EventArgs e)
        {

        }

        private void lHr_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            timer1.Stop();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            timer1.Start();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            timer1.Stop();
            hours = mintues = seconds = 0;
            lHr.Text = append0(hours);
            lmin.Text = append0(mintues);
            lsec.Text = append0(seconds);

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds++;

            if (seconds > 59)
            {
                mintues++;
                seconds = 0;
            }

            if (mintues > 59)
            {
                hours++;
                mintues = 0;
            }

            lHr.Text = append0(hours);
            lmin.Text = append0(mintues);
            lsec.Text = append0(seconds);

            {
                this.progressBar.Increment(1);
            }
        }

        private string append0(double input)
        {
            if (input <= 9)
            {
                return "0" + input;

            }

            else
            {
                return input.ToString();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar_Click(object sender, EventArgs e)
        {

            this.timer1.Start();
        }

        private void b_prgrs_Click(object sender, EventArgs e)
        {

        }
    }

}

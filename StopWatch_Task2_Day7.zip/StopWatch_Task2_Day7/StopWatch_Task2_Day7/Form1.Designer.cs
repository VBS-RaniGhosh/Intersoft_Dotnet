﻿
namespace StopWatch_Task2_Day7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lHr = new System.Windows.Forms.Label();
            this.lmin = new System.Windows.Forms.Label();
            this.lsec = new System.Windows.Forms.Label();
            this.btn_pause = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_start = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // lHr
            // 
            this.lHr.AutoSize = true;
            this.lHr.Font = new System.Drawing.Font("Noto Serif Cond", 36F, System.Drawing.FontStyle.Bold);
            this.lHr.ForeColor = System.Drawing.Color.Chartreuse;
            this.lHr.Location = new System.Drawing.Point(164, 101);
            this.lHr.Margin = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.lHr.Name = "lHr";
            this.lHr.Size = new System.Drawing.Size(74, 65);
            this.lHr.TabIndex = 0;
            this.lHr.Text = "00";
            this.lHr.Click += new System.EventHandler(this.lHr_Click);
            // 
            // lmin
            // 
            this.lmin.AutoSize = true;
            this.lmin.Font = new System.Drawing.Font("Noto Serif Cond", 36F, System.Drawing.FontStyle.Bold);
            this.lmin.ForeColor = System.Drawing.Color.Chartreuse;
            this.lmin.Location = new System.Drawing.Point(278, 101);
            this.lmin.Margin = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.lmin.Name = "lmin";
            this.lmin.Size = new System.Drawing.Size(74, 65);
            this.lmin.TabIndex = 1;
            this.lmin.Text = "00";
            this.lmin.Click += new System.EventHandler(this.lmin_Click);
            // 
            // lsec
            // 
            this.lsec.AutoSize = true;
            this.lsec.Font = new System.Drawing.Font("Noto Serif Cond", 36F, System.Drawing.FontStyle.Bold);
            this.lsec.ForeColor = System.Drawing.Color.Chartreuse;
            this.lsec.Location = new System.Drawing.Point(392, 101);
            this.lsec.Margin = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.lsec.Name = "lsec";
            this.lsec.Size = new System.Drawing.Size(74, 65);
            this.lsec.TabIndex = 2;
            this.lsec.Text = "00";
            this.lsec.Click += new System.EventHandler(this.lsec_Click);
            // 
            // btn_pause
            // 
            this.btn_pause.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pause.ForeColor = System.Drawing.Color.Maroon;
            this.btn_pause.Location = new System.Drawing.Point(265, 182);
            this.btn_pause.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.btn_pause.Name = "btn_pause";
            this.btn_pause.Size = new System.Drawing.Size(100, 40);
            this.btn_pause.TabIndex = 3;
            this.btn_pause.Text = "Pause";
            this.btn_pause.UseVisualStyleBackColor = true;
            this.btn_pause.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stop.ForeColor = System.Drawing.Color.Red;
            this.btn_stop.Location = new System.Drawing.Point(379, 182);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(100, 40);
            this.btn_stop.TabIndex = 4;
            this.btn_stop.Text = "Reset";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_start
            // 
            this.btn_start.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_start.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_start.Location = new System.Drawing.Point(151, 182);
            this.btn_start.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(100, 40);
            this.btn_start.TabIndex = 5;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Noto Serif Cond", 36F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Chartreuse;
            this.label2.Location = new System.Drawing.Point(234, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 65);
            this.label2.TabIndex = 7;
            this.label2.Text = ":";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Noto Serif Cond", 36F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Chartreuse;
            this.label1.Location = new System.Drawing.Point(348, 101);
            this.label1.Margin = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 65);
            this.label1.TabIndex = 8;
            this.label1.Text = ":";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(151, 269);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(328, 23);
            this.progressBar.TabIndex = 9;
            this.progressBar.Click += new System.EventHandler(this.progressBar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(39F, 73F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InfoText;
            this.ClientSize = new System.Drawing.Size(646, 356);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_pause);
            this.Controls.Add(this.lsec);
            this.Controls.Add(this.lmin);
            this.Controls.Add(this.lHr);
            this.Font = new System.Drawing.Font("Linux Biolinum G", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(20, 16, 20, 16);
            this.Name = "Form1";
            this.Text = "Rani_StopWatch";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lHr;
        private System.Windows.Forms.Label lmin;
        private System.Windows.Forms.Label lsec;
        private System.Windows.Forms.Button btn_pause;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar;
    }
}


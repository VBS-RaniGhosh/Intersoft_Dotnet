﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


//using Newtonsoft.Json;
namespace DemoParamkeyword
{
    class Program
    {
        public void sk(params object[] rr)
        {
            foreach (var item in rr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            Program p1 = new Program();
            p1.sk("Rani", 21, "ranighosh041@gmail.com", "Hisar");
        }
    }
}

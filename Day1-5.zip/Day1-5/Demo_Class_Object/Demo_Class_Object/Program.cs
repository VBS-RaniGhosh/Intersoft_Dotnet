﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Demo_Class_Object
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car obj1 = new Car(); // Creating an Object of Car Class 
            Console.WriteLine(obj1.color);
        }
    }

    class Car
    {
        public string color = "Black";//Field/Arttribute
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_base_keyword
{
    internal class Animal
    {
        public string color = "yellow";
    }

    class Dog : Animal
    {

        string color = "Black";
        public void showColor()
        {
            Console.WriteLine($"Color coming from base class is {base.color}");
            Console.WriteLine($"Color define in current class is {color}");

        }
    }
}

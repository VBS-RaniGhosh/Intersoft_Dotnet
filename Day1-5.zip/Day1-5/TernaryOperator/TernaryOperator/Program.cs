﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TernaryOperator

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ternary Conditional Operator");
            int x = 20, y = 15;
            var result = x > y ? " X is greater than Y" :
                            x < y ? " X is less than Y" :
                                x == y ? " X is equal to y " : " No Result";
            Console.WriteLine(result);
        }
    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Class_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            GrandChild childObj = new GrandChild();
            childObj.read("MyName", "MySubject");
            CousinClass cousinObj = new CousinClass("Second Name", 19);
            cousinObj.read();

        }
    }
}
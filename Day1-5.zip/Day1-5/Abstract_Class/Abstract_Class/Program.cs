﻿using System;

using System.Collections.Generic;

using System.Text;

namespace Abstract_Class


{

    interface IDomesticAnimal

    {

        //We canot not define data members  

        //All methods are by default abstract and public  

        string Colortype();

        void NoLegs();

        int Weight();

        void Age();

        void Food_Type();



         int No_of_Kids { get; set; }

    }

    abstract class Animal

    {

        public abstract void speak();

        //{  



        //We cant provide function defination 

        //    Console.WriteLine("Testing "); 

        //} 



        public void AnimalLanguage()

        {

            Console.WriteLine("ZZZZZ....ZZZZ...Z.Z.Z.Z");

        }



    }



    class Dog : Animal, IDomesticAnimal

    {

        public int No_of_Kids { get; set; }



        public void Age()

        {

            throw new NotImplementedException();

        }



        public string Colortype()

        {

            throw new NotImplementedException();

        }



        public void Food_Type()

        {

            throw new NotImplementedException();

        }



        public void NoLegs()

        {

            throw new NotImplementedException();

        }



        public override void speak()

        {

            Console.WriteLine(" The Dog Says : Woof Woof ....");

        }



        public void Weight()

        {

            throw new NotImplementedException();

        }



        int IDomesticAnimal.Weight()

        {

            throw new NotImplementedException();

        }

    }



    class Cat : Animal, IDomesticAnimal

    {

        public int No_of_Kids { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }



        public void Age()

        {

            throw new NotImplementedException();

        }



        public string Colortype()

        {

            throw new NotImplementedException();

        }



        public void Food_Type()

        {

            throw new NotImplementedException();

        }



        public void NoLegs()

        {

            throw new NotImplementedException();

        }



        public override void speak()

        {

            Console.WriteLine(" The Cat Says Meow .. Meow....");

        }



        public void Weight()

        {

            throw new NotImplementedException();

        }



        int IDomesticAnimal.Weight()

        {

            throw new NotImplementedException();

        }

    }

}
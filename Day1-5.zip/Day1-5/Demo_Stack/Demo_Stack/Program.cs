﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack myStack = new Stack();
            myStack.Push("Hello");
            myStack.Push("World");
            myStack.Push("!");

            Console.WriteLine("MyStack");
            Console.WriteLine(myStack.Count);
            Console.WriteLine(myStack);
            foreach (string item in myStack)
            {
                Console.WriteLine(item);
            }

        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_NonGeneric
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array List Implementation - Non generic Collection");

            ArrayList myfav = new ArrayList();
            myfav.Add("Dell - latitude");
            myfav.Add(true);
            myfav.Add('R');
            myfav.Add(22);
            myfav.Add(2.14);
            myfav.Add(25.22D);
            myfav.Add('R');
            myfav.Add(22);
            myfav.Add(2.14);
            myfav.Add(25.22D);



            Console.WriteLine(myfav.Capacity);
            Console.WriteLine(myfav.Count);

            foreach (var item in myfav)
            {
                Console.WriteLine(item);
            }
            //myfav.Sort();//Will raise exception



            myfav.Reverse();

            foreach (var item in myfav)
            {
                Console.WriteLine(item);
            }
        }
    }
}
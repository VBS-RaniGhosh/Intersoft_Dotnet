﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor_cal
{
    class opt_cal
    {
        public int n = 0;

        public opt_cal()
        {

        }
        public opt_cal(int n1)
        {
            n = n1;
        }
        public static opt_cal operator + (opt_cal c1, opt_cal c2)
        {
            opt_cal res = new opt_cal(0);
            res.n = c2.n + c1.n;
            return res;
        }
        public void print()
        {
            Console.WriteLine("{0}", n);
        }
    }
}

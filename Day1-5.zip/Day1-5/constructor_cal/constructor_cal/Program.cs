﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructor_cal
{
    internal class Program

    {
        
        static void Main(string[] args)
        {
            opt_cal no1 = new opt_cal(40);
            opt_cal no2 = new opt_cal(90);
            opt_cal no3 = new opt_cal();

            no3 = no1 + no2;
            no1.print();
            no2.print();
            no3.print();


        }
    }
}

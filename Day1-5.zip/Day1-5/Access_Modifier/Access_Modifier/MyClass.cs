﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAccessModifier
{
    public class MyClass
    {
        public void GetPublic() { }
        private void GetPrivate() { }
        internal void getInterna() { }

        protected void GetProtected() { }
        protected internal void GetProtectedInternal() { }
        protected private void GetPrivateProtected() { }

    }
}


﻿using DemoAccessModifier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_Modifier
{
    class NewProgram

    {

        public void GetPublic() { }

        private void GetPrivate() { }

        internal void GetInternal() { }

        protected void GetProtected() { }

        protected internal void GetProtectedInternal() { }

        protected private void GetPrivateProtected() { }

    }

    internal class Program : NewProgram



    {

        public void show()

        {

            MyClass obj2 = new MyClass();

            GetProtected();

            GetPrivateProtected();

            GetInternal();

            GetProtectedInternal();



        }



        static void Main(string[] args)

        {

            NewProgram obj1 = new NewProgram();

            obj1.GetInternal();

            obj1.GetProtectedInternal();

            obj1.GetPublic();





        }

    }

}
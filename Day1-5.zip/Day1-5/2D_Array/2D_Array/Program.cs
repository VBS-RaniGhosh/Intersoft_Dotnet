﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2D_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] myarr = new int[3][];
            myarr[0] = new int[4] { 11, 12, 13, 14 };
            myarr[1] = new int[6] { 22, 33, 44, 55, 66, 77 };
            myarr[2] = new int[] { 1, 2, 3, };

            for (int item = 0; item < myarr.Length; item++)
            {
                for (int i = 0; i < myarr[item].Length; i++)
                {
                    Console.WriteLine(myarr[item][i] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}

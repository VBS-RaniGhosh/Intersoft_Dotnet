﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_implementation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary Implementaion");
            Dictionary<String, Int16> AuthorList = new Dictionary<String, Int16>();
            AuthorList.Add("Rani", 21);
            AuthorList.Add("Nisha", 22);
            AuthorList.Add("Anjali", 23);

            Dictionary<String, float> PriceList = new Dictionary<String, float>();
            PriceList.Add("Lemon Juice", 3.64f);
            PriceList.Add("Banana Shake", 2.95f);
            PriceList.Add("Orange Juice", 1.23f);

            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name: {item.Key}, Value: {item.Value}");

            }
            //Remove an element
            AuthorList.Remove("Nisha");
            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name: {item.Key}, Value: {item.Value}");

            }
            if (!AuthorList.ContainsKey("Nisha"))
            {
                AuthorList["Nisha"] = 24;
            }

            if (!AuthorList.ContainsValue(23))
            {
                Console.WriteLine("Item found");
            }

            //Clearing Collection
            Console.WriteLine("Count:" + AuthorList.Count);
            AuthorList.Clear();

            Console.WriteLine("Count:" + AuthorList.Count);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base_Keyword
{
    class Animal
    {
        public string Color = "Yellow";
        public virtual void speak()
        {
            Console.WriteLine("Animal speak from their heart!!!");
        }
    }
    class Dog : Animal
    {
        string color = "black";
        public override void speak()
        {
            Console.WriteLine("Dogs are very talkactive with their parents");
            Console.WriteLine($"base class speak() says:");
            base.speak();
        }
        public void showcolor()
        {
            Console.WriteLine($"Color coming from base calss is {base.Color}");
            Console.WriteLine($"Color define in current class is {color}");
        }
    }
}

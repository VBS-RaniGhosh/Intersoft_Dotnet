﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Anonymousdelegates
{
    public delegate int Mymydelegate();
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing anonymous delegate");
            Mymydelegate del1 = delegate ()
            {
                Console.WriteLine("Anonymousdelegate delegate");
                return 0; 
            };
            del1();
        }
    }
}

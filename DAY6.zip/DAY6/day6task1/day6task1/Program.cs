﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day6task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Define Exception");
            Age a = new Age();

            try
            {
                a.showAge();
            }
            catch (AgeIsLessThanTwenty ex)
            {
                Console.WriteLine("Age is less than 20", ex.Message);

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day6task1
{
    public class AgeIsLessThanTwenty : Exception
    {
        public AgeIsLessThanTwenty(string message)
        {

        }
    }
    class Age
    {
        int age1 = 21;
        
        public void showAge()
        {
            if (age1 < 20)
            {
                throw (new AgeIsLessThanTwenty("Age is less than 20"));
            }
            else
            {
                Console.WriteLine("Age : {0}", age1);
                Console.WriteLine("Valid Age");

            }
        }
    }
}

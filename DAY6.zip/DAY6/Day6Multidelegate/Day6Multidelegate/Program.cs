﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Multidelegate
{
 
    public delegate void delmethod(int x, int y); //  delegate Delcaration
    class Program
    {
        public void Add(int x, int y)
        {
            Console.WriteLine("You are implemtning Add()");
            Console.WriteLine(x + y);
        }
        public void Subtract(int x, int y)
        {
            Console.WriteLine("You ar ein subtract method");
            Console.WriteLine(x - y);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Program obj1 = new Program();
            delmethod del = new delmethod(obj1.Add);
            // Multicasting delegate is like this
            del += new delmethod(obj1.Subtract);
            del(45, 25);
            Console.WriteLine(" After reomoving the ref of add()");

            del -= new delmethod(obj1.Add);
            del(20, 25);
        }
    }
}
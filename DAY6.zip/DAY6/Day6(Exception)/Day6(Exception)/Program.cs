﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Exception_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Define Exception");
            Temprature temp = new Temprature();

            try
            {
                temp.showTemp();
            }
            catch (TempIsZeroException e)
            {
                Console.WriteLine("Temprature is Zero Exception: {0}", e.Message);
                throw;
            }
        }
    }
}
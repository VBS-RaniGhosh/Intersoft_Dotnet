﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Exception_
{
    public class TempIsZeroException : Exception
    {
        public TempIsZeroException(string message)
        {

        }
    }
    internal class Temprature
    {
        int temprature = 0;

        public void showTemp()


        {
            if (temprature == 0)
            {
                throw (new TempIsZeroException("Zero Temperature Found"));
            }

            else
            {
                Console.WriteLine("Temprature : {0}", temprature);
            }
        }

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Define Exception");
            Order o = new Order();

            try
            {
                o.showOrder();
            }
            catch (OrderIsMoreThanFive ex)
            {
                Console.WriteLine("Order is More than 5", ex.Message);

            }
        }
    }
}
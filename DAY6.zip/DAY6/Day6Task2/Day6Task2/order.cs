﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Task2
{
    public class OrderIsMoreThanFive : Exception
    {
        public OrderIsMoreThanFive(string message)
        {

        }
    }
    class Order
    {
        int ord = 4;

        public void showOrder()
        {
            if (ord > 5)
            {
                throw (new OrderIsMoreThanFive("Order is more than 5"));
            }
            else
            {
                Console.WriteLine("Order : {0}", ord);
                Console.WriteLine("Order is less than 5");

            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 3, 118, 3000, 16, 5};
            foreach (var i in arr)
            {
                Console.WriteLine(i);
              
            }
            Console.WriteLine();

            Console.WriteLine("************Last Element Is Deleted*********\n");
            var arr1 = arr.Take(arr.Length - 1).ToArray();
            foreach (var i in arr1)
            {
                Console.WriteLine(i);
           
            }
            Console.WriteLine();

            Console.WriteLine("**************After Sorting**************\n");
            Array.Sort(arr1);
            foreach (var i in arr1)
            {
                Console.WriteLine(i);
               
            }
            Console.WriteLine();

            Console.WriteLine("Min Value:" + arr1.Min()+"\n");
           

            Console.WriteLine("Max Value: " + arr1.Max()+"\n");
           

            Console.WriteLine("Sum of All Elements: " + arr1.Sum()+"\n");


        }

    }
}
﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Day12_MVC_ORM.Models
{
    public class RecordContext : DbContext
    {
        public RecordContext() : base()
        {

        }

        public DbSet<Students> Rani_Students_New { get; set; } //No of tables we want to create in DB

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=192.168.1.230;Initial Catalog=AdventureWorks2017;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022");
        }
    }
}
